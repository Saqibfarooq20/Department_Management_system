package com.example.dept_mgmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeptMgmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
